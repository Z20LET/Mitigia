
# Python Virtuális Környezet Létrehozása

A Python virtuális környezetek használata segít elkülöníteni a projektek függőségeit, és megakadályozza a globális Python telepítés összekuszálódását.

## 1. Ellenőrizd a Python telepítését
Győződj meg róla, hogy a Python telepítve van a rendszereden:

```bash
python --version
```

Ha a fenti parancs nem működik, próbáld ki a következőt:
```bash
python3 --version
```

## 2. Virtuális környezet létrehozása
Navigálj a projekt könyvtárába, majd hozz létre egy virtuális környezetet:

```bash
python -m venv venv
```

Alternatívaként, ha a `python3` parancsot használod:

```bash
python3 -m venv venv
```

## 3. Virtuális környezet aktiválása
Aktiváld a virtuális környezetet az operációs rendszerednek megfelelően:

- **Windows**:
  ```bash
  .\venv\Scripts\activate
  ```

- **Linux/macOS**:
  ```bash
  source venv/bin/activate
  ```

Ha sikerült az aktiválás, a terminál elején megjelenik a `(venv)` jelzés.

## 4. Függőségek telepítése
Most már telepítheted a projekted függőségeit, például:

```bash
pip install -r requirements.txt
```

## 5. Virtuális környezet deaktiválása
Ha végeztél, deaktiváld a virtuális környezetet:

```bash
deactivate
```

## 6. Virtuális környezet törlése
Ha már nincs szükséged a virtuális környezetre, egyszerűen törölheted a `venv` könyvtárat:

```bash
rm -rf venv
```

---

### Hasznos Parancsok
- Telepített csomagok listázása:
  ```bash
  pip list
  ```
- Egy konkrét csomag telepítése:
  ```bash
  pip install <csomag_neve>
  ```
- Egy csomag eltávolítása:
  ```bash
  pip uninstall <csomag_neve>
  ```

### Megjegyzés
Mindig használd a virtuális környezetet Python projektekhez, hogy elkerüld a globális környezet szennyezését.

