#!/bin/bash

# Update the package list and install prerequisites
sudo dnf upgrade -y

# Install the latest version of Python 3
sudo dnf install -y python3 python3-pip

# Install Python 3 latest pip
python3 -m pip install --upgrade pip

# Create a virtual environment
python3 -m venv venv

# Activate the virtual environment
source venv/bin/activate

# Upgrade pip within the virtual environment
pip install --upgrade pip

# Confirm that pip is available and install required packages from requirements.txt
pip install -r requirements.txt

# Install cron
sudo dnf install -y cronie

# Enable and start the cron service
sudo systemctl enable crond
sudo systemctl start crond

# Create a cron job to run the scripts hourly
(crontab -l 2>/dev/null; echo "0 * * * * /home/ec2-user/PythonScraper/venv/bin/python /home/ec2-user/PythonScraper/carbon_intensity.py") | crontab -
(crontab -l 2>/dev/null; echo "0 * * * * /home/ec2-user/PythonScraper/venv/bin/python /home/ec2-user/PythonScraper/power_breakdown.py") | crontab -

# Print a message indicating completion
echo "Setup complete. The scripts will run hourly."
