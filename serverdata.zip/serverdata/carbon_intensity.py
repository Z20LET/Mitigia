import requests
import csv
from datetime import datetime
from requests.exceptions import ConnectionError, Timeout

def fetch_and_save_data(zones):
    base_url = "https://api.electricitymap.org/v3/carbon-intensity/latest?zone="
    headers = {"auth-token": "aTkxkVdODBiVT"}  # Replace "myapitoken" with your real API token.
    current_date = datetime.now().strftime("%Y.%m.%d")
    current_time = datetime.now().strftime("%H:%M")

    data_dict = {'Date': current_date, 'Time': current_time}

    for zone in zones:
        url = f"{base_url}{zone}"
        
        # Retry mechanizmus
        max_retries = 10
        for attempt in range(max_retries):
            try:
                response = requests.get(url=url, headers=headers)
                
                if response.status_code == 200:
                    data = response.json()
                    carbon_intensity = data.get('carbonIntensity', 'N/A')
                    data_dict[zone] = carbon_intensity  # Add the carbon intensity for the zone to the dict
                    break  # Sikeres válasz esetén kilép a retry ciklusból
                else:
                    print(f"Failed to fetch data for zone {zone}: {response.status_code}")
                    data_dict[zone] = 'N/A'  # Add 'N/A' if the fetch failed
                    break  # Ha nem sikerült lekérni az adatokat, lépj ki, nincs értelme újrapróbálkozni
                
            except (ConnectionError, Timeout) as e:
                print(f"Attempt {attempt+1} failed for zone {zone}. Retrying...")
                if attempt == max_retries - 1:
                    print(f"Failed to fetch data for zone {zone} after {max_retries} attempts.")
                    data_dict[zone] = 'N/A'  # Add 'N/A' if the fetch failed after retries

    # Write data to CSV
    current_year = datetime.now().strftime("%Y")
    csv_file = f"carbon_intensity_data_{current_year}.csv"
    fieldnames = ['Date', 'Time'] + zones  # Header row for CSV

    try:
        # Check if file exists and if it does, append without header; otherwise, create it with header
        with open(csv_file, 'a', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            if file.tell() == 0:  # If file is empty, write header
                writer.writeheader()
            writer.writerow(data_dict)  # Write the data row
    except IOError as e:
        print(f"I/O error({e.errno}): {e.strerror}")

# List of zones to call
zones = ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE", "IT", "LV", "LT", "LU",  "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE", "NO", "CH", "GB"]  # Add or remove zones as needed, "MT" = MALTA IS NOT FOUND, 2024.09.26 ADDED NO,CH,GB
fetch_and_save_data(zones)
